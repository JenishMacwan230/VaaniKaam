import express from "express";
import verifyAuthToken from "../middleware/verifyAuthToken";
import { registerUser, loginWithPassword, requestOtp, verifyOtp, addRole, switchRole, getMe } from "../controllers/userController";

const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginWithPassword);
router.post("/request-otp", requestOtp);
router.post("/verify-otp", verifyOtp);

router.post("/add-role", verifyAuthToken, addRole as any);
router.post("/switch-role", verifyAuthToken, switchRole as any);
router.get("/me", verifyAuthToken, getMe as any);

export default router;
