import mongoose, { Document, Schema } from "mongoose";

export interface IOtpCode extends Document {
  phone: string;
  codeHash: string;
  expiresAt: Date;
}

const otpCodeSchema: Schema = new Schema(
  {
    phone: { type: String, required: true, index: true },
    codeHash: { type: String, required: true },
    expiresAt: { type: Date, required: true },
  },
  { timestamps: true }
);

otpCodeSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export default mongoose.model<IOtpCode>("OtpCode", otpCodeSchema);
