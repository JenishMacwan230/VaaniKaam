import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User, { allowedRoles } from "../models/User";
import OtpCode from "../models/OtpCode";

const normalizeRoles = (roles: any): string[] => {
  if (!Array.isArray(roles)) return [];
  return roles.filter((r) => allowedRoles.includes(r));
};

const createToken = (user: any) => {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET is not set");
  return jwt.sign({ userId: user._id.toString(), activeRole: user.activeRole }, secret, { expiresIn: "7d" });
};

export const registerUser = async (req: Request, res: Response) => {
  try {
    const { name, email, phone, password, roles, activeRole } = req.body || {};
    if (!phone || !password) return res.status(400).json({ message: "Phone and password are required" });
    const existingByPhone = await User.findOne({ phone });
    if (existingByPhone) return res.status(409).json({ message: "Phone already in use" });
    if (email) {
      const existingByEmail = await User.findOne({ email: email.toLowerCase() });
      if (existingByEmail) return res.status(409).json({ message: "Email already in use" });
    }
    const desiredRoles = normalizeRoles(roles);
    const nextActiveRole = allowedRoles.includes(activeRole) ? activeRole : null;
    const initialRoles = desiredRoles.length > 0 ? desiredRoles : ["worker"];
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email: email?.toLowerCase(), phone, passwordHash, roles: initialRoles, activeRole: nextActiveRole && initialRoles.includes(nextActiveRole) ? nextActiveRole : initialRoles[0] });
    const token = createToken(user);
    return res.status(201).json({ user, token });
  } catch (error) {
    return res.status(500).json({ message: "Failed to register user" });
  }
};

export const loginWithPassword = async (req: Request, res: Response) => {
  try {
    const { email, phone, password } = req.body || {};
    if ((!email && !phone) || !password) return res.status(400).json({ message: "Credentials are required" });
    const user = await User.findOne(email ? { email: email.toLowerCase() } : { phone });
    if (!user || !user.passwordHash) return res.status(401).json({ message: "Invalid credentials" });
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) return res.status(401).json({ message: "Invalid credentials" });
    if (!user.isActive) return res.status(403).json({ message: "User is deactivated" });
    const token = createToken(user);
    return res.json({ user, token });
  } catch (error) {
    return res.status(500).json({ message: "Failed to login" });
  }
};

export const requestOtp = async (req: Request, res: Response) => {
  try {
    const { phone } = req.body || {};
    if (!phone) return res.status(400).json({ message: "Phone is required" });
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const codeHash = await bcrypt.hash(code, 10);
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
    await OtpCode.deleteMany({ phone });
    await OtpCode.create({ phone, codeHash, expiresAt });
    const response: any = { message: "OTP sent" };
    if (process.env.OTP_DEBUG === "true") response.otp = code;
    return res.json(response);
  } catch (error) {
    return res.status(500).json({ message: "Failed to request OTP" });
  }
};

export const verifyOtp = async (req: Request, res: Response) => {
  try {
    const { phone, code, name, email } = req.body || {};
    if (!phone || !code) return res.status(400).json({ message: "Phone and OTP are required" });
    const record = await OtpCode.findOne({ phone });
    if (!record || record.expiresAt < new Date()) return res.status(401).json({ message: "OTP expired" });
    const isMatch = await bcrypt.compare(code, record.codeHash);
    if (!isMatch) return res.status(401).json({ message: "Invalid OTP" });
    let user = await User.findOne({ phone });
    if (!user) {
      if (email) {
        const existingByEmail = await User.findOne({ email: email.toLowerCase() });
        if (existingByEmail) return res.status(409).json({ message: "Email already in use" });
      }
      user = await User.create({ name, email: email?.toLowerCase(), phone, roles: ["worker"], activeRole: "worker" });
    }
    if (!user.isActive) return res.status(403).json({ message: "User is deactivated" });
    await OtpCode.deleteMany({ phone });
    const token = createToken(user);
    return res.json({ user, token });
  } catch (error) {
    return res.status(500).json({ message: "Failed to verify OTP" });
  }
};

export const addRole = async (req: Request & any, res: Response) => {
  try {
    const { role } = req.body || {};
    const user = req.user;
    if (!user) return res.status(401).json({ message: "Unauthorized" });
    if (!allowedRoles.includes(role)) return res.status(400).json({ message: "Invalid role" });
    if (!user.roles.includes(role)) user.roles.push(role);
    if (!user.activeRole) user.activeRole = role;
    await user.save();
    return res.json({ user });
  } catch (error) {
    return res.status(500).json({ message: "Failed to add role" });
  }
};

export const switchRole = async (req: Request & any, res: Response) => {
  try {
    const { role } = req.body || {};
    const user = req.user;
    if (!user) return res.status(401).json({ message: "Unauthorized" });
    if (!allowedRoles.includes(role)) return res.status(400).json({ message: "Invalid role" });
    if (!user.roles.includes(role)) return res.status(403).json({ message: "Role not assigned" });
    user.activeRole = role;
    await user.save();
    return res.json({ user });
  } catch (error) {
    return res.status(500).json({ message: "Failed to switch role" });
  }
};

export const getMe = async (req: Request & any, res: Response) => {
  try {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    return res.json({ user: req.user });
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch user" });
  }
};
